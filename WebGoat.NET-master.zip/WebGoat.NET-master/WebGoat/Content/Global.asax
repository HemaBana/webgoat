<%@ Application Inherits="DotNetGoat.Global" %>
